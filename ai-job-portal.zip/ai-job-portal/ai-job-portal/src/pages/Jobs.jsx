export default function Jobs() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Jobs Page</h1>
    </div>
  );
}
